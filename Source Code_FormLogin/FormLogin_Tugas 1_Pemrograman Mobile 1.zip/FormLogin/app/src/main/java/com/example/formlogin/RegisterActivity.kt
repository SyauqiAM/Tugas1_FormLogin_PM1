package com.example.formlogin

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class RegisterActivity : AppCompatActivity() {

    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var etConfirm: EditText
    private lateinit var btnDaftar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        etConfirm = findViewById(R.id.etConfirm)
        btnDaftar = findViewById(R.id.btnDaftar)

        btnDaftar.setOnClickListener {
            val email = etEmail.text.toString()
            val password = etPassword.text.toString()
            val confirm = etConfirm.text.toString()

            if (email.isEmpty() || password.isEmpty() || confirm.isEmpty()){
                Toast.makeText(this, "Isi Semua Form!", Toast.LENGTH_SHORT).show()
            }else if (password != confirm){
                Toast.makeText(this, "Password Tidak Sama", Toast.LENGTH_SHORT).show()
            }else {
                Toast.makeText(this, "Register Berhasil", Toast.LENGTH_SHORT).show()
            }
        }
    }
}